package handlers

import (
	"database/sql"
	"encoding/json"
	"net/http"
	"strconv"

	"cybercalc/internal/auth"
	"cybercalc/internal/middleware"
	"cybercalc/internal/models"
)

type AdminHandlers struct {
	DB *sql.DB
}

// --- Пользователи (в т.ч. создание дополнительных админов) -----------------

type createUserRequest struct {
	Email      string  `json:"email"`
	Password   string  `json:"password"`
	FullName   string  `json:"full_name"`
	Role       string  `json:"role"` // admin|user
	EntityType string  `json:"entity_type,omitempty"`
	PartnerID  *string `json:"partner_id,omitempty"`
}

func (h *AdminHandlers) CreateUser(w http.ResponseWriter, r *http.Request, admin middleware.AuthUser) {
	var req createUserRequest
	if err := decodeJSON(r, &req); err != nil {
		middleware.WriteError(w, http.StatusBadRequest, "некорректный запрос")
		return
	}
	if req.Role != string(models.RoleAdmin) && req.Role != string(models.RoleUser) {
		middleware.WriteError(w, http.StatusBadRequest, "role должен быть admin или user")
		return
	}
	hash, err := auth.HashPassword(req.Password)
	if err != nil {
		middleware.WriteError(w, http.StatusInternalServerError, "ошибка хеширования пароля")
		return
	}

	var entityType interface{}
	if req.EntityType != "" {
		entityType = req.EntityType
	}
	var id string
	err = h.DB.QueryRow(
		`INSERT INTO users (email, password_hash, full_name, role, entity_type, partner_id)
		 VALUES ($1,$2,$3,$4,$5,$6) RETURNING id`,
		req.Email, hash, req.FullName, req.Role, entityType, req.PartnerID,
	).Scan(&id)
	if err != nil {
		middleware.WriteError(w, http.StatusConflict, "не удалось создать пользователя (возможно, email уже занят): "+err.Error())
		return
	}
	logAudit(h.DB, "user", id, "create", admin.ID, "", nil, map[string]string{"email": req.Email, "role": req.Role})
	middleware.WriteJSON(w, http.StatusCreated, map[string]string{"id": id})
}

func (h *AdminHandlers) ListUsers(w http.ResponseWriter, r *http.Request, admin middleware.AuthUser) {
	rows, err := h.DB.Query(`SELECT id, email, full_name, role, entity_type, partner_id, is_active, created_at
		FROM users ORDER BY created_at`)
	if err != nil {
		middleware.WriteError(w, http.StatusInternalServerError, "ошибка запроса")
		return
	}
	defer rows.Close()
	var out []models.User
	for rows.Next() {
		var u models.User
		var entityType, partnerID sql.NullString
		if err := rows.Scan(&u.ID, &u.Email, &u.FullName, &u.Role, &entityType, &partnerID, &u.IsActive, &u.CreatedAt); err != nil {
			middleware.WriteError(w, http.StatusInternalServerError, "ошибка чтения")
			return
		}
		if entityType.Valid {
			u.EntityType = models.EntityType(entityType.String)
		}
		if partnerID.Valid {
			p := partnerID.String
			u.PartnerID = &p
		}
		out = append(out, u)
	}
	middleware.WriteJSON(w, http.StatusOK, out)
}

type updateUserRequest struct {
	IsActive *bool   `json:"is_active,omitempty"`
	Role     *string `json:"role,omitempty"`
}

func (h *AdminHandlers) UpdateUser(w http.ResponseWriter, r *http.Request, admin middleware.AuthUser, userID string) {
	var req updateUserRequest
	if err := decodeJSON(r, &req); err != nil {
		middleware.WriteError(w, http.StatusBadRequest, "некорректный запрос")
		return
	}
	if req.IsActive != nil {
		h.DB.Exec(`UPDATE users SET is_active = $1, updated_at = now() WHERE id = $2`, *req.IsActive, userID)
	}
	if req.Role != nil {
		if *req.Role != string(models.RoleAdmin) && *req.Role != string(models.RoleUser) {
			middleware.WriteError(w, http.StatusBadRequest, "role должен быть admin или user")
			return
		}
		h.DB.Exec(`UPDATE users SET role = $1, updated_at = now() WHERE id = $2`, *req.Role, userID)
	}
	logAudit(h.DB, "user", userID, "update", admin.ID, "", nil, req)
	middleware.WriteJSON(w, http.StatusOK, map[string]string{"status": "ok"})
}

// --- Настройки (сроки хранения и т.п.) -------------------------------------

func (h *AdminHandlers) GetSettings(w http.ResponseWriter, r *http.Request, admin middleware.AuthUser) {
	rows, err := h.DB.Query(`SELECT key, value FROM settings`)
	if err != nil {
		middleware.WriteError(w, http.StatusInternalServerError, "ошибка запроса")
		return
	}
	defer rows.Close()
	out := map[string]string{}
	for rows.Next() {
		var k, v string
		rows.Scan(&k, &v)
		out[k] = v
	}
	middleware.WriteJSON(w, http.StatusOK, out)
}

type updateSettingRequest struct {
	Key   string `json:"key"`
	Value string `json:"value"`
}

// UpdateSetting позволяет админу регулировать, например,
// attachment_retention_days ("но администратор может это регулировать" — ТЗ).
func (h *AdminHandlers) UpdateSetting(w http.ResponseWriter, r *http.Request, admin middleware.AuthUser) {
	var req updateSettingRequest
	if err := decodeJSON(r, &req); err != nil {
		middleware.WriteError(w, http.StatusBadRequest, "некорректный запрос")
		return
	}
	if req.Key == "" {
		middleware.WriteError(w, http.StatusBadRequest, "key обязателен")
		return
	}
	if req.Key == "audit_log_retention_days" {
		if v, err := strconv.Atoi(req.Value); err != nil || v <= 0 {
			middleware.WriteError(w, http.StatusBadRequest, "audit_log_retention_days должен быть положительным числом")
			return
		}
	}
	_, err := h.DB.Exec(
		`INSERT INTO settings (key, value, updated_by) VALUES ($1,$2,$3)
		 ON CONFLICT (key) DO UPDATE SET value = $2, updated_by = $3, updated_at = now()`,
		req.Key, req.Value, admin.ID,
	)
	if err != nil {
		middleware.WriteError(w, http.StatusInternalServerError, "ошибка сохранения")
		return
	}
	logAudit(h.DB, "settings", req.Key, "settings_change", admin.ID, "", nil, req)
	middleware.WriteJSON(w, http.StatusOK, map[string]string{"status": "ok"})
}

// --- Журнал изменений (виден только админам, хранится N дней) --------------

func (h *AdminHandlers) AuditLog(w http.ResponseWriter, r *http.Request, admin middleware.AuthUser) {
	q := r.URL.Query()
	conds := []string{"1=1"}
	args := []interface{}{}
	arg := func(v interface{}) string {
		args = append(args, v)
		return "$" + strconv.Itoa(len(args))
	}
	if v := q.Get("entity_type"); v != "" {
		conds = append(conds, "entity_type = "+arg(v))
	}
	if v := q.Get("user_id"); v != "" {
		conds = append(conds, "user_id = "+arg(v))
	}
	limit := 200
	if v := q.Get("limit"); v != "" {
		if n, err := strconv.Atoi(v); err == nil && n > 0 && n <= 1000 {
			limit = n
		}
	}

	query := `SELECT id, entity_type, entity_id, action, user_id, comment_text, old_value, new_value, created_at
		FROM audit_log WHERE ` + joinAnd(conds) + ` ORDER BY created_at DESC LIMIT ` + strconv.Itoa(limit)
	rows, err := h.DB.Query(query, args...)
	if err != nil {
		middleware.WriteError(w, http.StatusInternalServerError, "ошибка запроса: "+err.Error())
		return
	}
	defer rows.Close()

	var out []models.AuditLogItem
	for rows.Next() {
		var item models.AuditLogItem
		var entityID, userID, comment sql.NullString
		var oldRaw, newRaw []byte
		if err := rows.Scan(&item.ID, &item.EntityType, &entityID, &item.Action, &userID, &comment, &oldRaw, &newRaw, &item.CreatedAt); err != nil {
			middleware.WriteError(w, http.StatusInternalServerError, "ошибка чтения")
			return
		}
		if entityID.Valid {
			v := entityID.String
			item.EntityID = &v
		}
		if userID.Valid {
			v := userID.String
			item.UserID = &v
		}
		if comment.Valid {
			v := comment.String
			item.CommentText = &v
		}
		if len(oldRaw) > 0 {
			json.Unmarshal(oldRaw, &item.OldValue)
		}
		if len(newRaw) > 0 {
			json.Unmarshal(newRaw, &item.NewValue)
		}
		out = append(out, item)
	}
	middleware.WriteJSON(w, http.StatusOK, out)
}
